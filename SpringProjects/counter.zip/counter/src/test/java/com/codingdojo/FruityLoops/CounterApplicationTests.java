package com.codingdojo.FruityLoops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
