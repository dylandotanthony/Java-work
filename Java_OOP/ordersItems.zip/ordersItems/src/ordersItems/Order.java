package ordersItems;
import java.util.ArrayList;


public class Order {
	
	// Member Variables 
	
	public String name;
	
	public double total;
	
	public boolean ready;
	
	public ArrayList<Item> items = new ArrayList<Item>();

}
