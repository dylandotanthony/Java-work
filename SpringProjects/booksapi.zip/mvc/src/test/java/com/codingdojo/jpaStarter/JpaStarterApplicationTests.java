package com.codingdojo.jpaStarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
