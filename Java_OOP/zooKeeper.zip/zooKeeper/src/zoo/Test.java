package zoo;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla gorillas = new Gorilla();
		
		
		
		gorillas.throwSomething(); // -5
		gorillas.displayEnergy(); // 95
		gorillas.eatBananas(); // +10
		gorillas.displayEnergy(); // 105
		gorillas.throwSomething(); // -5
		gorillas.displayEnergy(); // 100
		gorillas.eatBananas(); // +10
		gorillas.displayEnergy(); // 110
		gorillas.throwSomething(); // -5
		gorillas.displayEnergy(); // 105
		gorillas.climb(); // -10
		gorillas.displayEnergy(); // 95


	}

}
