public class Test {
    public static void main(String[] args){
        System.out.println("My Name is Dylan Anthony");
        System.out.println("I am 29 years old");
        System.out.println("My hometown is Pueblo, CO");
    }
}
