/**
 * 
 */
/**
 * @author dylan
 *
 */
module careSoftInterfaces {
}