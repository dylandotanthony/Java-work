package CafeJava;

public class test {
    
}
